document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("cislo1");

    input.addEventListener("input", () => {
        const a = Number(input.value);

        if (isNaN(a)) {
            document.body.style.backgroundColor = "white"; // default/fallback color
            return;
        }

        if (a > 30) {
            document.body.style.backgroundColor = "red";
        } else if (a < 10) {
            document.body.style.backgroundColor = "blue";
        } else {
            document.body.style.backgroundColor = "green";
        }
    });
});