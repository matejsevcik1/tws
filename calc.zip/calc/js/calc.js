function secti1() {
    // Načti hodnoty z obou vstupů a převeď je na čísla
    let a = document.getElementById("cislo1").value*1;
    let b = document.getElementById("cislo2").value*1;

    // Sečti hodnoty
    let soucet = a + b;

    // Zobraz výsledek
    document.getElementById("vysledek").value = soucet;
}
function secti2() {
    // Načti hodnoty z obou vstupů a převeď je na čísla
    let a = document.getElementById("cislo1").value*1;
    let b = document.getElementById("cislo2").value*1;

    // Sečti hodnoty
    let soucet = a - b;

    // Zobraz výsledek
    document.getElementById("vysledek").value = soucet;
}                                                                                                                             
function secti3() {
    // Načti hodnoty z obou vstupů a převeď je na čísla
    let a = document.getElementById("cislo1").value*1;
    let b = document.getElementById("cislo2").value*1;

    // Sečti hodnoty
    let soucet = a * b;

    // Zobraz výsledek
    document.getElementById("vysledek").value = soucet;
}                                                                                                                             
function secti4() {
    // Načti hodnoty z obou vstupů a převeď je na čísla
    let a = document.getElementById("cislo1").value*1;
    let b = document.getElementById("cislo2").value*1;

    // Sečti hodnoty
    let soucet = a / b;

    // Zobraz výsledek
    document.getElementById("vysledek").value = soucet;
}                                                                                                                                                                                                                                                          