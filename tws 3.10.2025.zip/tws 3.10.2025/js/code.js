function secti(){
let a = document.getElementById("cislo1").value*1;


if (a > 30){
    document.body.style.backgroundColor = "red"
} else if (a < 10){
    document.body.style.backgroundColor = "blue"
}else{
    document.body.style.backgroundColor = "green"
}
}